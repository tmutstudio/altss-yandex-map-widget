=== ASS Yandex Map Widget ===
Tags: Yandex Map Widget, altss
Requires at least: 5.9
Tested up to: 6.8.2
Stable tag: 1.1.1
Requires PHP: 7.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin is an extension of the Alternative Site Settings plugin for adding a Yandex Maps widget to a website.

== Changelog ==

= 1.1.1 =
* rename Requires Plugins.

= 1.1.0 =
* Initial release.

